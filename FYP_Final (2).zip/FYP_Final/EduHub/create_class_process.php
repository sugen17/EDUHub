<!DOCTYPE html>
<html>
<head>
    <title>Delete Class</title>
    <link rel="stylesheet" type="text/css" href="Teacher_drop.css">
</head>
<body>
    <?php
    session_start();

    // Check if the teacher is logged in
    if (!isset($_SESSION['teacher_id'])) {
        // Redirect to the login page or display an error message
        header("Location: login.php");
        exit();
    }

    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "eduhub_database";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and bind the INSERT statement
    $stmt = $conn->prepare("INSERT INTO classes (xteacher_id, class_name, class_code, class_image) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $teacher_id, $class_name, $class_code, $class_image);

    // Set parameters and execute
    $teacher_id = $_SESSION['teacher_id'];
    $class_name = $_POST['class_name'];
    $class_code = $_POST['class_code'];
    $class_image = $_FILES['class_image']['name']; // Assuming 'class_image' is the name of the file input field
    $target_dir = "uploads/"; // Directory where images will be stored
    $target_file = $target_dir . basename($_FILES["class_image"]["name"]);

    // Move uploaded file to specified directory
    if (move_uploaded_file($_FILES["class_image"]["tmp_name"], $target_file)) {
        // File uploaded successfully
    } else {
        echo "Sorry, there was an error uploading your file.";
    }

    echo '<div class="notif">';
    // Execute the prepared statement
    if ($stmt->execute()) {
        echo "<p class='success'>Class created successfully!</p>";
        echo "<button class='button' onclick=\"location.href='teachers_homepage.php'\">Go Back to Classes</button>";
    } else {
        echo "Error: " . $conn->error;
    }
    echo '</div>';
    // Close statement and connection
    $stmt->close();
    $conn->close();
    ?>
</body>
</html>