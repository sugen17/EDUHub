<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="update_teacher_profile.css">
    <title>Update Teacher Profile</title>
</head>
<body>
    <header>
        <h1>EduHub</h1>
    </header>
    <div class="top">
            <button onclick="history.back()">Cancel</button>
    </div>
    <div class="main">
        <h2>Update Profile</h2>
        <form action="update_teacher_process.php" method="post" enctype="multipart/form-data">
            <label for="name">Name:</label><br>
            <input type="text" id="name" name="name"><br>
            <label for="bio">Bio:</label><br>
            <textarea id="bio" name="bio"></textarea><br>
            <label for="profile_pic">Profile Picture:</label><br>
            <input type="file" id="profile_pic" name="profile_pic"><br><br>
            <input type="submit" value="Update">
        </form>
    </div>
    
</body>
</html>
