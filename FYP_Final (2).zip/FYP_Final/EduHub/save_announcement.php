<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get user ID from session or any other means of identifying the user
    $class_id = $_SESSION['id']; // Adjust this according to how you identify users

    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "eduhub_database";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare data for insertion
    $topic = $_POST['topic'];
    $caption = $_POST['caption'];
    $due_date = $_POST['due_date'];

    // File upload handling
    $attachment = '';
    if(isset($_FILES["attachment"]) && $_FILES["attachment"]["error"] == 0) {
        $target_dir = "attachments/";
        $target_file = $target_dir . basename($_FILES["attachment"]["name"]);
        if (move_uploaded_file($_FILES["attachment"]["tmp_name"], $target_file)) {
            $attachment = $target_file;
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }

    // Insert announcement into database
    $sql = "INSERT INTO announcements (user_id, topic, caption, attachment, due_date) VALUES ('$user_id', '$topic', '$caption', '$attachment', '$due_date')";

    if ($conn->query($sql) === TRUE) {
        echo "Announcement added successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close connection
    $conn->close();
}
?>
