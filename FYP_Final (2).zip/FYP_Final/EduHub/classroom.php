<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eduhub_database";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$class_id = $_GET['class_id'];



?>


<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="classroom.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Classroom</title>
</head>
<body>
    
    <header>
        <h1>EduHub</h1>
    </header>
    <div class="top">
        <a href="homepage.php"><p class="choose"> Back to classrooms </p></a>
            <div class="dropdown" style="float:right;">
                <img src="FYP Images/dropdown.png" class="dropbtn">
                <div class="dropdown-content">
                    <a href="#">Classroom</a>
                  <a href="s_announcements.php?class_id=<?php echo $class_id; ?>">Announcements</a>
                  <a href="classwork.php?class_id=<?php echo $class_id; ?>">Classwork</a>
                  <a href="students.php?class_id=<?php echo $class_id; ?>">Students</a>
                </div>
            </div>
            <a href="student_profile.php"><img class="profile" src="FYP Images/Profile pic.jpg"></a>
    </div>
    <!--<div class="select">
        <a href="announcements.php?class_id=<?php echo $class_id; ?>"><p>Announcements</p></a>
        <a href="classwork.php?class_id=<?php echo $class_id; ?>"><p>Classwork</p></a>
        <a href="students.php?class_id=<?php echo $class_id; ?>"><p>Students</p></a>
    </div>-->


    <?php

    if (isset($_GET['class_id'])) {
        

        // Query the classes table to get class details
        $classSql = "SELECT * FROM classes WHERE id = $class_id";
        $classResult = $conn->query($classSql);

        if ($classResult->num_rows > 0) {
            $classRow = $classResult->fetch_assoc();
            $classname = $classRow['class_name'];
            $lecturerId = $classRow['xteacher_id'];

            // Query the teachers table to get lecturer's name
            $lecturerSql = "SELECT * FROM teachers WHERE teacher_id = $lecturerId";
            $lecturerResult = $conn->query($lecturerSql);

            if ($lecturerResult === false) {
                die("Error in lecturer query: " . $conn->error);
            }

            if ($lecturerResult->num_rows > 0) {
                $lecturerRow = $lecturerResult->fetch_assoc();
                $lecturer = $lecturerRow['NAME'];
            } else {
                $lecturer = "Unknown Lecturer";
            }


            $announcementSql = "SELECT * FROM announcements WHERE class_id = $class_id";
            $announcementResult = $conn->query($announcementSql);
            

            ?>
            <main class="main">
                <div class="class">
                    <p class="classname"><?php echo $classname; ?></p>
                </div>
                <div class="pic">
                    <img src="uploads/<?php echo $classRow['class_image']; ?>">
                </div>
                <div class="section">
                    <div class="section1">
                        <p class="work">Impending Work Due</p>
                        <?php
                        $currentDateTime = date("Y-m-d H:i:s");

                        $upcomingWorkSql = "SELECT topic FROM announcements WHERE class_id = $class_id AND due_date > CURDATE() OR (due_date = CURDATE() AND due_time > CURTIME())";
                        $upcomingWorkResult = $conn->query($upcomingWorkSql);
                        
                        if ($upcomingWorkResult === false) {
                            die("Error in upcoming work query: " . $conn->error);
                        }

                        if ($upcomingWorkResult->num_rows > 0) {
                            while ($workRow = $upcomingWorkResult->fetch_assoc()) {
                                ?>
                                <p class="due"><?php echo $workRow['topic']; ?></p>
                                <?php
                            }
                        } else {
                            echo "<p class='due'>No Work Due...</p>";
                        }
                        
                        ?>
                    </div>
                    <div class="section2">
                        <p class="lecturer">
                            <img class="lec" src="<?php echo $lecturerRow['teachers_pic']; ?>">
                            <?php echo $lecturer; ?>
                        </p>

                        <?php
                        if ($announcementResult === false) {
                            die("Error in announcement query: " . $conn->error);
                        }
                        if ($announcementResult->num_rows > 0) {
                            while ($announcementRow = $announcementResult->fetch_assoc()) {
                                ?>
                                <p class="announce">
                                    Topic: <?php echo $announcementRow['topic']; ?><br>
                                    Caption: <?php echo $announcementRow['caption']; ?><br>
                                    Due Date: <?php echo $announcementRow['due_date']; ?><br>
                                    Due Time: <?php echo $announcementRow['due_time']; ?><br>
                                    Document Names: 
                                    <?php
                                    $documentNames = explode(',', $announcementRow['document_names']);
                                    foreach ($documentNames as $documentName) {
                                        $documentPath = "uploads/" . trim($documentName);
                                        ?>
                                        <a href="<?php echo $documentPath; ?>" download><?php echo $documentName; ?></a><br>
                                        <?php
                                    }
                                    ?>
                                </p>
                                <?php
                            }
                        } else {
                            echo "<p class='announce'>No announcements available.</p>";
                        }
                        ?>
                    </div>
                </div>
            </main>
            <?php
        } else {
            echo "Class not found.";
        }
    } else {
        echo "Invalid class ID.";
    }
    ?>


</body>
</html>

