<?php

if (isset($_GET['class_id'])) {
    $class_id = $_GET['class_id'];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "eduhub_database";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="view_work.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Classroom</title>
    <style>
        p {
            color: white;
        }
    </style>

</head>
<body>
    <header>
        <h1>EduHub</h1>
    </header>
    <div class="top">
        <a href="teachers_homepage.php">
            <p class="choose">Back to Homepage </p>
        </a> 
        <a href="teacher_profile.php"><img class="profile" src="FYP Images/Profile pic.jpg"></a>
    </div>
    <div class="select">
        <a href="teachers_classroom.php?class_id=<?php echo $class_id; ?>">Classroom</a>
        <a href="add_announcements.php?class_id=<?php echo $class_id; ?>">Add Announcements</a>
        <a href="announcements.php?class_id=<?php echo $class_id; ?>">Announcements</a>
        <a href="t_students.php?class_id=<?php echo $class_id; ?>">Students</a>
        <a href="#">View Submitted Work</a>

    </div>
    <?php
        $submissionsQuery = "SELECT student_id, file_path, topic FROM submissions WHERE class_id = $class_id";
        $submissionsResult = $conn->query($submissionsQuery);

        echo '<div class="main">';
        if ($submissionsResult !== false) {
            if ($submissionsResult->num_rows > 0) {
                while ($submissionRow = $submissionsResult->fetch_assoc()) {
                    echo "<div class='submission'>";
                    echo "<p><strong>Student ID:</strong> " . $submissionRow['student_id'] . "</p>";
                    echo "<p><strong>Topic:</strong> " . $submissionRow['topic'] . "</p>";
                    echo "<p><strong>File Path:</strong> " . $submissionRow['file_path'] . "</p>";
                    
                    echo "<a href='" . $submissionRow['file_path'] . "' download style='display: block; margin-top: 10px;'>Download File</a>";
                    echo "</div>";
                }
            } else {
                echo "No submitted work found for this class.";
            }
        } else {
            echo "Error in query: " . $conn->error;
        }
        echo '</div>';
    ?>
    
</body>
</html>
