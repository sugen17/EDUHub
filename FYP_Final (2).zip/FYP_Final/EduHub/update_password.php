<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $new_password = $_POST['new_password'];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "eduhub_database";
    
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

    $sql = "UPDATE teachers SET password='$hashed_password' WHERE email='$email'";
    if ($conn->query($sql) === TRUE) {
        echo "<p>Password updated successfully!</p>";
    } else {
        echo "Error updating password: " . $conn->error;
    }

    $conn->close();
}
?>
