<?php
session_start();


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "eduhub_database";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $classCode = $_POST["classCode"];

    $sqlCheckClass = "SELECT * FROM classes WHERE class_code = '$classCode'";
    $resultCheckClass = $conn->query($sqlCheckClass);

    if ($resultCheckClass->num_rows > 0) {

        $userId = $_SESSION['student'];  
        $classId = $resultCheckClass->fetch_assoc()['id'];
        $enrollmentDate = date("Y-m-d H:i:s");

        $sqlInsertEnrollment = "INSERT INTO enrollment_table (enrollment_date, id, user_id, xclass_code)
                               VALUES ('$enrollmentDate', '$classId', '$userId', '$classCode')";

        if ($conn->query($sqlInsertEnrollment) === TRUE) {
            echo "<script>alert('Class joined successfully'); window.location.href='homepage.php';</script>";
        } else {
            echo "<script>alert('Error occurred while joining the class');</script>";
        }
    } else {
        echo "<script>alert('Class not found. Please check the class code and try again.'); window.location.href='Add_class.php';</script>";
    }
} else {
    echo "<script>alert('Invalid request method');</script>";
}
?>
