<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Profile</title>
</head>
<body>
    <div class="profile-container">
        <?php
        session_start();

        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "eduhub_database";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $admin_id = $_SESSION['admin'];
        $sql = "SELECT * FROM admins WHERE admin_id = '$admin_id'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $teacher_id = $row['admin_id'];
            $teacher_email = $row['email'];

            echo '
                <p>ID: ' . $admin_id . '</p>
                <p>Email: ' . $teacher_email . '</p>
                    <button type="submit">Update Profile</button>
                </form>';

            echo '<form action="logout_admin.php" method="post">
                    <button type="submit">Logout</button>
                </form>';
        } else {
            echo "Admin not found.";
        }

        $conn->close();
        ?>
    </div>
</body>
</html>
