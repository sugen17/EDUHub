<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: student login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eduhub_database";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION['username'];
$query = "SELECT user_id, email, pic, fullname, bio FROM users WHERE email='$username'";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $user_id = $row['user_id'];
    $email = $row['email'];
    $pic = $row['pic'];
    $fullname = $row['fullname'];
    $bio = $row['bio'];
} else {
    $user_id = "null";
    $email = "null";
    $pic = "null";
    $fullname = "null";
    $bio = "null";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="student_profile.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EduHub</title>
</head>
<body>
<header>
    <h1>EduHub</h1>
</header>
<main>
    <div class="top">
        <button onclick="history.back()">Go back</button>
    </div>
    <div class="main">
        <h1>Personal Info</h1>
        <img src="profile_pics/<?php echo $pic; ?>" alt="Profile Picture">
        <br>
        <h2>Full Name : <?php echo $fullname; ?></h2>
        <br></br>
        <h2>ID : <?php echo $user_id; ?></h2>
        <br></br>
        <h2>Email : <?php echo $email; ?></h2>
        <br></br>
        <h2>Bio : <?php echo $bio; ?></h2>
        <br></br>
        <input type="button" class="but" value="Update Details" onclick="redirectToUpdate()">
        <input type="button" class="but" onclick="redirectToLogout()" value="Logout">
    </div>
</main>

<script>
    function redirectToUpdate() {
        window.location.href = "update_profile.html";
    }
    function redirectToLogout() {
        window.location.href = "logout_student.php";
    }
</script>
</body>
</html>
