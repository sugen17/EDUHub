<?php
session_start();





?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Class</title>
    <link rel="stylesheet" href="Add_class.css">
    <style>
        .container {
            display: flex;
            flex-direction:column;
            padding: 40px; /* Increased padding for better spacing */
            border-radius: 25px; /* Increased border radius */
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
            width: 25%; /* Adjust the width as needed */
            height: 50%;
            text-align: center;
        }

        h1 {
            color: white; /* Header color */
            margin-bottom: 30px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 8px;
            margin-right: 20px;
            color: white; /* Label color */
        }

        input {
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid black;
            border-radius: 8px;
        }

        input:hover{
            box-shadow:0 0 5px black;
        }

        button {
            padding: 12px;
            margin-top:20px;
            margin-bottom:10px;
            background-color: white; /* Darker button color */
            border: 1px solid black;
            color: black;
            border-radius: 8px;
            cursor: pointer;
            transition: transform .6s;
        }

        button:hover{
            box-shadow:0 0 5px black;
            background-color: rgb(210, 210, 210);
            transform: scale(1.1);
        }

        .responsive {
            width: 100%;
            height: auto;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Add Class</h1>

        <form id="joinClassForm" action="join_class.php" method="post">
            <label for="classcode">Classcode:</label>
            <input type="text" id="classCode" name="classCode" required>

            <button type="submit">Join Class</button>
            <button type="submit" onclick="history.back()">Cancel</button>
        </form>

    </div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>


    
</body>
</html>

