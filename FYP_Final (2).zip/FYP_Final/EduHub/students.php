<?php

if (isset($_GET['class_id'])) {
    $class_id = $_GET['class_id'];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "eduhub_database";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="studentlist.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Classroom</title>
</head>
<body>
    <header>
        <h1>EduHub</h1>
    </header>
    <div class="top">
        <a href="homepage.php"><p class="choose"> Back to Homepage </p></a>
            <div class="dropdown" style="float:right;">
                <img src="FYP Images/dropdown.png" class="dropbtn">
                <div class="dropdown-content">
                  <a href="classroom.php?class_id=<?php echo $class_id; ?>">Classroom</a>
                  <a href="s_announcements.php?class_id=<?php echo $class_id; ?>">Announcements</a>
                  <a href="classwork.php?class_id=<?php echo $class_id; ?>">Classwork</a>
                  <a href="#">Students</a>
                </div>
            </div>
            <a href="student_profile.php"><img class="profile" src="FYP Images/Profile pic.jpg"></a>
    </div>
    <!--<div class="select">
        <a href="add_announcements.php?class_id=<?php echo $class_id; ?>"><button>Add Announcements</button></a>
        <a href="announcements.php?class_id=<?php echo $class_id; ?>"><button>Announcements</button></a>
        <a href="students.php?class_id=<?php echo $class_id; ?>"><button>Students</button></a>
        <a href="view_submitted_work.php?class_id=<?php echo $class_id; ?>"><button>View Submitted Work</button></a>

    </div> -->
    <main class="main">
        <div class="class">
            <?php
                $classNameSql = "SELECT * FROM classes WHERE id = $class_id";
                $classNameResult = $conn->query($classNameSql);

                if ($classNameResult === false) {
                    die("Error in class name query: " . $conn->error);
                }

                if ($classNameResult->num_rows > 0) {
                    $classRow = $classNameResult->fetch_assoc();
                    $class_name = $classRow['class_name'];

                    ?>
                    <p class="classname" src='uploads/'><?php echo $class_name; ?> - Enrolled Students:</p>
                    <?php
                } else {
                    echo "Class not found.";
                }
            ?>
        </div>
        <!-- <div class="pic">
            <img src="uploads/<?php echo $classRow['class_image']; ?>">
        </div> -->
        <div class="section">
            <?php
                $enrollmentSql = "SELECT user_id FROM enrollment_table WHERE id = $class_id";
                $enrollmentResult = $conn->query($enrollmentSql);

                if ($enrollmentResult === false) {
                    die("Error in enrollment query: " . $conn->error);
                }

                if ($enrollmentResult->num_rows > 0) {
                    while ($enrollmentRow = $enrollmentResult->fetch_assoc()) {
                        $user_id = $enrollmentRow['user_id'];

                        $userSql = "SELECT * FROM users WHERE user_id = $user_id";
                        $userResult = $conn->query($userSql);

                        if ($userResult === false) {
                            die("Error in user query: " . $conn->error);
                        }

                        if ($userResult->num_rows > 0) {
                            ?>
                            <ul class="user-list">
                                <?php
                                while ($userRow = $userResult->fetch_assoc()) {
                                    $user_email = $userRow['email'];
                                    $profile_pic = $userRow['pic'];
                                    ?>
                                    <li class="user-item">
                                        <p class="user-email">Student Email: <?php echo $user_email; ?></p>
                                        <img class="profile-pic" src="profile_pics/<?php echo $profile_pic; ?>" alt="User Profile Pic">
                                    </li>
                                    <?php
                                }
                                ?>
                            </ul>
                            <?php
                        } else {
                            echo "User not found.";
                        }

                    }
                } else {
                    echo "No user enrolled in this class.";
                }
            } else {
                echo "Invalid class ID.";
            }
            ?>
        </div>
    </main>
</body>
</html>
