<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Teacher Forget Password</title>
  <link rel="stylesheet" href="teacher_forget_password.css">
  <style>
        body {
      font-family: 'Arial', sans-serif;
      background-color: #343a40; /* Dark background color */
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
      margin: 0;
    }

    .container {
      display: flex;
      flex-direction: column;
      width: 500px;
      height: 500px;
      background-image: linear-gradient(rgb(37, 37, 37),rgb(117, 117, 117));
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.5); /* Darker shadow */
      overflow: hidden;
    }

    #reset-password-container{
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%,-50%);
    max-width: 430px;
    width: 100%;
    background-image: linear-gradient(rgb(37, 37, 37),rgb(117, 117, 117));
    border-radius: 7px;
    box-shadow: 0 5px 10px rgba(255, 255, 255, 0.3);
    }

    input {
      width: 100%;
      padding: 12px;
      margin: 18px 0;
      box-sizing: border-box;
      background-color: white; /* Dark input background color */
      color: black; /* Light text color */
      border: 1px solid black; /* Slightly lighter border color */
      border-radius: 5px;
    }

    input:hover{
      box-shadow: 0 0 5px black;
    }

    form {
      padding: 20px;
    }

    .head {
      text-align: center;
      color: white;
      font-size: 24px;
      margin-bottom: 20px;
      margin-top: 30px;
    }

    a {
      color: black;
      text-decoration: none;
      margin-bottom: 10px;
      display: inline-block;
    }

    .button {
      background-color: white;
      color: black;
      border: 1px solid black;
      border-radius: 5px;
      padding: 12px;
      cursor: pointer;
      width: 100%;
      transition: transform .6s;
    }

    .button:hover{
      box-shadow: 0 0 5px black;
      transform: scale(1.05);
      background-color: rgb(210,210,210);
    }
    </style>
</head>
<body>
    <div class="container">
      <h1 class="head">Forget Password</h1>
      <form action="teachers_forget_password.php" method="post" id="forget-password-form">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br>
        <label for="teacher_id">Teacher ID:</label>
        <input type="text" id="teacher_id" name="teacher_id" required><br>
        <input type="submit" value="Submit">
      </form>
    </div>
    
    <div id="reset-password-container" style="display:none;">
      <h1 class="head">Reset Password</h1>
      <form action="update_password.php" method="post" id="reset-password-form">
        <input type="hidden" name="email" value="">
        <label for="new_password">New Password (Minimum 8 characters):</label>
        <input type="password" id="new_password" name="new_password" required minlength="8"><br>
        <input type="submit" value="Update Password">
      </form>
    </div>
  

  <?php
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $teacher_id = $_POST['teacher_id'];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "eduhub_database";
    
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql = "SELECT * FROM teachers WHERE email = '$email' AND teacher_id = '$teacher_id'";
    $result = $conn->query($sql);

    echo '<div id="reset-password-container">';
    if ($result->num_rows > 0) {
      echo '<h2>Reset Password</h2>';
      echo '<form action="update_password.php" method="post" id="reset-password-form">';
      echo '<input type="hidden" name="email" value="' . $email . '">';
      echo '<label for="new_password">New Password (Minimum 8 characters):</label>';
      echo '<input type="password" id="new_password" name="new_password" required minlength="8"><br>';
      echo '<input type="submit" value="Update Password">';
      echo '</form>';
    } else {
      echo '<p>No matching record found. Please check your email and teacher ID.</p>';
    }
    echo '</div>';
    $conn->close();
  }
  ?>

<!--<script>
  document.getElementById('forget-password-form').addEventListener('submit', function(event) {
    event.preventDefault();
    document.getElementById('container').style.display = 'none';
    document.getElementById('reset-password-container').style.display = 'flex';
  });
</script>-->
<script>
      document.getElementById('forget-password-form').addEventListener('submit', function(event) {
        event.preventDefault();
        document.querySelector('.container').style.display = 'none';
        document.getElementById('reset-password-container').style.display = 'block';
      });
</script>
</body>
</html>
