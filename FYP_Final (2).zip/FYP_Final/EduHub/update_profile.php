<!DOCTYPE html>
<html>
<head>
    <title>Delete Class</title>
    <link rel="stylesheet" type="text/css" href="Teacher_drop.css">
</head>
<body>
    <?php
    session_start();

    // Check if user is logged in
    if (!isset($_SESSION['username'])) {
        header("Location: login.php");
        exit();
    }

    // Connect to the database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "eduhub_database";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    echo '<div class="notif">';
        // Handle form submission
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $fullname = $_POST['fullname'];
            $bio = $_POST['bio'];
            $pic = $_FILES['pic']['name'];

            // Move uploaded file to desired location (optional)
            $target_dir = "profile_pics/";
            $target_file = $target_dir . basename($pic);
            move_uploaded_file($_FILES["pic"]["tmp_name"], $target_file);

            // Update user's profile in the database
            $username = $_SESSION['username'];
            $query = "UPDATE users SET fullname='$fullname', bio='$bio', pic='$pic' WHERE email='$username'";
            if ($conn->query($query) === TRUE) {
                echo "<p class='success'>Profile updated successfully</p>";
                echo "<button class='button' onclick=\"location.href='homepage.php'\">Proceed to Homepage</button>";            
            } else {
                echo "<p class='error'>Error updating profile: </p>" . $conn->error;
                echo "<button class='button' onclick=\"location.href='homepage.php'\">Proceed to Homepage</button>";            
            }
        }
    echo '</div>';
    // Close the database connection
    $conn->close();
    ?>
</body>
</html>