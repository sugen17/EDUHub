<?php
session_start();

if (!isset($_SESSION['student'])) {
    header("Location: student login.html");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Process form submission
    $class_code = $_POST['class_code'];
    $user_id = $_SESSION['student'];

    // Perform validation on class code (you may add more validation as needed)
    if (!empty($class_code)) {
        // Connect to your database
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "eduhub_database";
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Prepare and execute SQL to drop student from class
        $sql = "DELETE FROM enrollment_table WHERE user_id = $user_id AND xclass_code = '$class_code'";
        if ($conn->query($sql) === TRUE) {
            // Student dropped successfully
            echo '<script>alert("You have been successfully dropped from the class."); window.location.href = "homepage.php";</script>';
        } else {
            // Error dropping student
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        $conn->close();
    } else {
        // Class code not provided
        echo "Please provide a valid class code.";
    }
} else {
    // Handle case where form is not submitted
    echo "Form submission error.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="drop_class.css">
    <title>Drop Class</title>
    <style>
        .container {
            display: flex;
            flex-direction:column;
            padding: 40px; /* Increased padding for better spacing */
            border-radius: 25px; /* Increased border radius */
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
            width: 25%; /* Adjust the width as needed */
            height: 50%;
            text-align: center;
        }

        h1 {
            color: white; /* Header color */
            margin-bottom: 30px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 8px;
            margin-right: 20px;
            color: black; /* Label color */
        }

        input {
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid black;
            border-radius: 8px;
            cursor: pointer;
            transition: transform .6s;
        }

        input:hover{
            box-shadow:0 0 5px black;
            transform: scale(1.1);
        }

        button {
            padding: 12px;
            margin-top:20px;
            margin-bottom:10px;
            background-color: white; /* Darker button color */
            border: 1px solid black;
            color: black;
            border-radius: 8px;
            cursor: pointer;
            transition: transform .6s;
        }

        button:hover{
            box-shadow:0 0 5px black;
            background-color: rgb(210, 210, 210);
            transform: scale(1.1);
        }

        .responsive {
            width: 100%;
            height: auto;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Drop Class</h1>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="classcode">Class Code:</label><br>
            <input type="text" id="class_code" name="class_code"><br>
            <input type="submit" value="Drop from Class">
            <button type="button" onclick="history.back()">Cancel</button>
        </form>
    </div>
    
</body>
</html>
