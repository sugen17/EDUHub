<!DOCTYPE html>
<html>
<head>
    <title>Delete Class</title>
    <link rel="stylesheet" type="text/css" href="Teacher_drop.css">
</head>
<body>
    <?php
    // Connect to the database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "eduhub_database";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $signupEmail = $_POST['signupEmail'];
        $signupPassword = $_POST['signupPassword'];
        $confirmPassword = $_POST['confirmPassword'];

        // Validate and insert teacher information into the database
        if ($signupPassword === $confirmPassword) {
            // Generate a unique custom teacher ID
            $customTeacherId = generateUniqueTeacherId($conn);

            // Hash the password
            $hashedPassword = password_hash($signupPassword, PASSWORD_DEFAULT);

            // Insert data into the teachers table
            $insertQuery = "INSERT INTO teachers (teacher_id, email, password) VALUES ('$customTeacherId', '$signupEmail', '$hashedPassword')";

            echo '<div class="notif">';
            if ($conn->query($insertQuery) === TRUE) {
                echo "<p class='success'>Teacher signup successful!</p>";
                echo "<button class='button' onclick=\"location.href='teacher_login.html'\">Proceed to Homepage</button>";            

                $subject = "Welcome to EduHub";
                $message = "Thank you for signing up as a teacher! Your teacher ID is: $customTeacherId";
                $headers = "From: businesseduhub@gmail.com"; // Replace with your Gmail address
                
                // Uncomment the line below when you're ready to test on a live server
                // mail($signupEmail, $subject, $message, $headers);
                
            } else {
                echo "Error: " . $insertQuery . "<br>" . $conn->error;
            }
        } else {
            echo "<p class='error'>Passwords do not match!</p>";
            echo "<button class='button' onclick=\"location.href='teacher_login.html'\">Go Back to signup</button>";            
        }
        echo '</div>';
    }

    // Close the database connection
    $conn->close();

    // Function to generate a unique teacher ID
    function generateUniqueTeacherId($conn) {
        $nextId = 0;

        do {
            // Generate a numeric part of the teacher ID
            $query = "SELECT MAX(CAST(SUBSTRING(teacher_id, 7) AS SIGNED)) + 1 AS next_id FROM teachers";
            $result = $conn->query($query);

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $nextId = $row['next_id'];
            } else {
                // If there are no existing teachers, start from 1
                $nextId = 1;
            }

            // Generate the complete teacher ID (with 6 digits)
            $customTeacherId = "2222" . str_pad($nextId, 4, '0', STR_PAD_LEFT);

            // Check if the generated teacher ID already exists
            $checkQuery = "SELECT teacher_id FROM teachers WHERE teacher_id = '$customTeacherId'";
            $checkResult = $conn->query($checkQuery);

        } while ($checkResult->num_rows > 0);

        return $customTeacherId;
    }
    ?>
</body>
</html>