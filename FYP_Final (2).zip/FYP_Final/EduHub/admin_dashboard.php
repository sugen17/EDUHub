<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eduhub_database";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EduHub Admin Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');

        body {
            font-family: 'Poppins', sans-serif;
            background-image: url("admin.jpg");
            margin: 0;
            padding: 0;
        }

        .top {
            background-color: #343a40;
            padding: 15px;
            display: flex;
            justify-content: center;
        }

        .profile {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            cursor: pointer;
        }

        .main {
            display: flex;
            justify-content: center;
            align-items: center;
            height: calc(100vh - 70px);
        }

        .card {
            background-color: #ffffff;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 20px;
            width: 200px;
            cursor: pointer;
            margin: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .card:hover {
            box-shadow: 0 4px 8px white;
        }

        .card h2 {
            margin-top: 0;
            margin-bottom: 10px;
        }

        @media (max-width: 600px) {
            .main {
                flex-direction: column;
            }
        }
        header{
            background-color: #2b2b2b;
            color: white;
            padding: 8px;
            text-align: center;
        }
    </style>
</head>
<body>
<header>
    <h1>EduHub</h1>
</header>
    
<main class="main">
    <div class="card" onclick="goToEnrollStudent()">
        <h2>Enroll Student</h2>
    </div>
    <div class="card" onclick="goToDropStudent()">
        <h2>Drop Student</h2>
    </div>
    <div class="card" onclick="goToEnrollTeacher()">
        <h2>Enroll Teacher</h2>
    </div>
    <div class="card" onclick="goToDropTeacher()">
        <h2>Drop Teacher</h2>
    </div>
</main>
<script>
    function openAdminProfile() {
        window.location.href = 'admin_profile.php';
    }

    function goToEnrollStudent() {
        window.location.href = 'enroll_student.php';
    }

    function goToDropStudent() {
        window.location.href = 'drop_student.php';
    }

    function goToEnrollTeacher() {
        window.location.href = 'enroll_teacher.php';
    }

    function goToDropTeacher() {
        window.location.href = 'drop_teacher.php';
    }
</script>
</body>
</html>