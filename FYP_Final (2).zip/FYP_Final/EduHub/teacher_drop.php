<!DOCTYPE html>
<html>
<head>
    <title>Delete Class</title>
    <link rel="stylesheet" type="text/css" href="Teacher_drop.css">
</head>
<body>
    <?php
    session_start();

    // Check if the teacher is logged in
    if (!isset($_SESSION['teacher_id'])) {
        // Redirect to the login page or display an error message
        header("Location: login.php");
        exit();
    }

    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "eduhub_database";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    echo '<div class="notif">';
    // Check if class id is provided and delete the class from the database
    if (isset($_GET['class_id'])) {
        $class_id = $_GET['class_id'];
        // SQL to delete class from database
        $sql = "DELETE FROM classes WHERE id = $class_id";
        
        if ($conn->query($sql) === TRUE) {
            // Class deleted successfully
            echo "<p class='success'>Class deleted successfully.<p>";
            echo "<button class='button' onclick=\"location.href='teachers_homepage.php'\">Go Back to Classes</button>";            
        } else {
            echo "<p class='error'>Error deleting class: <p>" . $conn->error;
        }
    }
    echo '</div>';

    // Close connection
    $conn->close();
    ?>
</body>
</html>