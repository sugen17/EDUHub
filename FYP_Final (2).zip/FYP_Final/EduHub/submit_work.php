<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eduhub_database";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $class_id = $_POST['class_id'];
    $topic = $_POST['topic'];

    $getClassQuery = "SELECT class_name FROM classes WHERE id = $class_id";
    $classResult = $conn->query($getClassQuery);

    if ($classResult === false) {
        die("Error in class query: " . $conn->error);
    }

    if ($classResult->num_rows > 0) {
        $classRow = $classResult->fetch_assoc();
        $class_name = $classRow['class_name'];

        $target_dir = "uploads/" . $class_name . "/"; // Directory based on class_name
        $target_file = $target_dir . basename($_FILES['file_submission']['name']);

        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        move_uploaded_file($_FILES['file_submission']['tmp_name'], $target_file);

        $sql = "INSERT INTO submissions (class_id, class_name, topic, student_id, file_path)
        VALUES ('$class_id', '$class_name', '$topic', '$_SESSION[student]', '$target_file')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Work submitted successfully'); window.location.href='classwork.php?class_id=$class_id';</script>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }


    } else {
        echo "Class not found.";
    }

}
?>
