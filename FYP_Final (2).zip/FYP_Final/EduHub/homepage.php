<?php
session_start();

if (!isset($_SESSION['student'])) {
    header("Location: student login.html");
    exit();
}



$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eduhub_database";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="homepage.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EduHub</title>
    <script>
        function openStudentProfile() {
            window.location.href = 'student_profile.php';
        }

        function goToEnroll() {
            window.location.href = 'Add_class.php';
        }
        function goToDrop() {
            window.location.href = 'Drop_class.php';
        }
    </script>
</head>
<body>
<header>
    <h1>EduHub</h1>
</header>
<main>
    <div class="top">
        <p class="choose" onclick="goToEnroll()"> Enroll </p><p class="choose" onclick="goToDrop()"> Drop </p>
        <img class="profile" src="FYP Images/Profile pic.jpg" onclick="openStudentProfile()">
    </div>
    <div class="main">
        <h2>Welcome to EduHub!</h2>
        <p>Ready to learn more?</p>
        <div class="select">
        <?php
            $user_id = isset($_SESSION['student']) ? $_SESSION['student'] : null;

            if ($user_id) {
                $sql = "SELECT e.*, c.class_image, c.class_name, class_code
                        FROM enrollment_table e
                        INNER JOIN classes c ON e.id = c.id
                        WHERE e.user_id = $user_id";

                $result = $conn->query($sql);

                while ($row = $result->fetch_assoc()) {
                    $class_id = $row['id'];
                    $class_image = $row['class_image'];
                    $class_name = $row['class_name'];
                    $class_code = $row['class_code'];
                    ?>
                    
                        <a href="classroom.php?class_id=<?php echo $class_id; ?>" class="class-link">
                            <?php echo $class_name; ?> 
                            <?php echo '-'?>
                            <?php echo $class_code; ?> 
                            <img class="image" src="uploads/<?php echo $class_image; ?>">
                        </a>
                    <?php
                }
            }
            ?>

        </div>
    </div>
</main>
</body>
</html>
