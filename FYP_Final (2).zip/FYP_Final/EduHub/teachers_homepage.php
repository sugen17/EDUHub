<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="t_homepage.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EduHub</title>
    <script>
         function openTeachersProfile() {
        window.location.href = 'teacher_profile.php';
    }

        function addclass() {
            window.location.href = 'create_class.php';
        }
    </script>
    <style>
        .choose{
            font-size: 18px;
            margin-left: 15px;
            margin-top: 10px;
            margin-right: 10px;
            text-decoration: none;
            color: white;
            transition: transform .6s;
        }

        .choose:hover{
            transform: scale(1.3);
            cursor: pointer;
            color: white;
        }

    </style>
</head>
<body>
<header>
    <h1>EduHub</h1>
</header>
<main>
<div class="top">
    <p class="choose" onclick="addclass()"> Add Class </p>
    <img class="profile" src="FYP Images/Profile pic.jpg" onclick="openTeachersProfile()">
</div>

    <div class="main">
        <h2>Welcome to EduHub!</h2>
        <p>Ready to learn more?</p>
       
        <?php
session_start();

// Check if the teacher is logged in
if (!isset($_SESSION['teacher_id'])) {
    // Redirect to the login page or display an error message
    header("Location: login.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eduhub_database";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch classes from database
// Fetch classes from database
$sql = "SELECT id, class_name, class_image, class_code FROM classes WHERE xteacher_id = " . $_SESSION['teacher_id'];
$result = $conn->query($sql);




if ($result->num_rows > 0) {
    // Output image and button for each class
    while ($row = $result->fetch_assoc()) {
        $image_path = "uploads/" . $row['class_image']; // Update this with the actual path to your images directory
        $class_code = $row['class_code']; 
        echo '<div class="select">';
        echo '<a href="teachers_classroom.php?class_id=' . $row['id'] . '&teacher_id=' . $_SESSION['teacher_id'] . '"><div class="class-container">';
        echo '<p class="class-name">' . $row['class_name'] . ' - ' . $row['class_code'] . '</p>';
        echo '<img class="class-image" src="' . $image_path . '" alt="' . $row['class_name'] . '">';
        /*echo '<a href="teachers_classroom.php?class_id=' . $row['id'] . '&teacher_id=' . $_SESSION['teacher_id'] . '"><button class="class-button">' . $row['class_name'] . '</button></a>';*/
        echo '<a href="teacher_drop.php?class_id=' . $row['id'] . '" class="drop-link">Drop</a>'; // Link to delete class
        echo '</div></a>';
        echo '</div>';
    }
    
    
} else {
    echo "No classes found.";
}

/*var_dump($_SESSION['teacher_id']);*/

// Close connection
$conn->close();
?>

    </div>
</main>
</body>
</html>
