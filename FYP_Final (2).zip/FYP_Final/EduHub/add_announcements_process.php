<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "eduhub_database";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }


    // Prepare data for insertion
    $class_id = $_POST['class_id'];
    echo $class_id;
    $topic = $_POST['topic'];
    $caption = $_POST['caption'];
    $due_date = $_POST['due_date'];
    $due_time = $_POST['due_time'];

    // File handling
    $document_names = [];
    $files = $_FILES['files'];
    foreach ($files['tmp_name'] as $key => $tmp_name) {
        $file_name = $files['name'][$key];
        $file_tmp = $tmp_name;
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($file_name);
        move_uploaded_file($file_tmp, $target_file);
        $document_names[] = $file_name;
    }
    $document_names_str = implode(',', $document_names);

    // Insert announcement into database
    $sql = "INSERT INTO announcements (class_id, topic, caption, document_names, due_date, due_time)
            VALUES ('$class_id', '$topic', '$caption', '$document_names_str', '$due_date', '$due_time')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Announcement added successfully'); window.location.href='add_announcements.php?class_id=$class_id';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
} else {
    echo "Invalid request";
}
?>
