<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Class</title>
    <link rel="stylesheet" href="Add_class.css">
    <style>
        .container {
            display: flex;
            flex-direction:column;
            padding: 40px; /* Increased padding for better spacing */
            border-radius: 25px; /* Increased border radius */
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
            width: 25%; /* Adjust the width as needed */
            height: 53%;
            text-align: center;
        }

        h1 {
            color: white; /* Header color */
            margin-bottom: 10px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 2px;
            margin-right: 20px;
            color: white; /* Label color */
        }

        input[type="text"]{
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid black;
            border-radius: 8px;
        }

        input[type="text"]:hover{
            box-shadow:0 0 5px black;
        }

        input[type="file"] {
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 8px;
            align-items : center;
        }


        button {
            padding: 12px;
            margin-top:10px;
            margin-bottom:5px;
            background-color: white; /* Darker button color */
            border: 1px solid black;
            color: black;
            border-radius: 8px;
            cursor: pointer;
            transition: transform .6s;
        }

        button:hover{
            box-shadow:0 0 5px black;
            background-color: rgb(210, 210, 210);
            transform: scale(1.1);
        }

        .responsive {
            width: 100%;
            height: auto;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Create a New Class</h1>
        <form action="create_class_process.php" method="POST" enctype="multipart/form-data">
            <label for="class_name">Class Name:</label>
            <input type="text" id="class_name" name="class_name" required>
            
            <label for="class_code">Class Code:</label>
            <input type="text" id="class_code" name="class_code" required>
            
            <label for="class_image">Class Image:</label>
            <input type="file" id="class_image" name="class_image" accept="image/*" required>
            
            <button type="submit">Create Class</button>
            <button type="submit" onclick="history.back()">Cancel</button>

        </form>
    </div>
    
</body>
</html>
