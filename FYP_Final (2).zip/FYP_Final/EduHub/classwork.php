<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eduhub_database";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$class_id = $_GET['class_id'];

$today = date("Y-m-d H:i:s");
$announcementsQuery = "
    SELECT a.*
    FROM announcements a
    LEFT JOIN submissions s ON a.topic = s.topic AND s.class_id = $class_id
    WHERE a.class_id = $class_id
    AND a.due_date > '$today'
    AND s.topic IS NULL
    ORDER BY a.due_date ASC";
$announcementsResult = $conn->query($announcementsQuery);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="classwork.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Classwork</title>
</head>
<body>
    
    <header>
        <h1>EduHub</h1>
    </header>
    <div class="top">
        <a href="homepage.php"><p class="choose"> Back to Homepage </p></a>
            <div class="dropdown" style="float:right;">
                <img src="FYP Images/dropdown.png" class="dropbtn">
                <div class="dropdown-content">
                  <a href="classroom.php?class_id=<?php echo $class_id; ?>">Classroom</a>
                  <a href="s_announcements.php?class_id=<?php echo $class_id; ?>">Announcements</a>
                  <a href="#">Classwork</a>
                  <a href="students.php?class_id=<?php echo $class_id; ?>">Students</a>
                </div>
            </div><a href="student_profile.php"><img class="profile" src="FYP Images/Profile pic.jpg"></a>
    </div>


    
    <div class="test">
        <h2>Upcoming Classwork</h2>
        <?php
        if ($announcementsResult->num_rows > 0) {
            while ($row = $announcementsResult->fetch_assoc()) {
                echo "<div class='announcement'>";
                echo "<h3>Topic: " . $row['topic'] . "</h3>";
                echo "<p class='caption'><strong>Caption:</strong> ". $row['caption'] . "</p>";
                echo "<p class='caption'><strong>Due Date:</strong> " . $row['due_date'] . "</p>";
                echo "<p class='caption'><strong>Due Time:</strong> " . $row['due_time'] . "</p>";

                echo "<form action='submit_work.php' method='post' enctype='multipart/form-data'>";
                echo "<input type='hidden' name='class_id' value='" . $class_id . "'>"; 
                echo "<input type='hidden' name='topic' value='" . $row['topic'] . "'>"; 
                echo "<input type='file' name='file_submission'>";
                echo "<input type='submit' value='Submit Work'>";
                echo "</form>";


                echo "</div>";
            }
        } else {
            echo "No upcoming classwork found for this class.";
        }
        ?>
    </div>
    
</body>
</html>
