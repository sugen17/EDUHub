<!DOCTYPE html>
<html>
<head>
    <title>Delete Class</title>
    <link rel="stylesheet" type="text/css" href="Teacher_drop.css">
</head>
<body>
    <?php
    session_start();

    // Check if the teacher is logged in
    if (!isset($_SESSION['teacher_id'])) {
        // Redirect to the login page or display an error message
        header("Location: login.php");
        exit();
    }

    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "eduhub_database";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    echo '<div class="notif">';
        // Check if form data is submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Collect form data
            $name = $_POST['name'];
            $bio = $_POST['bio'];
            
            // Upload profile picture
            $target_dir = "profile_pictures/"; // Directory where profile pictures will be stored
            $target_file = $target_dir . basename($_FILES["profile_pic"]["name"]);
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
            
            // Check if image file is a actual image or fake image
            $check = getimagesize($_FILES["profile_pic"]["tmp_name"]);
            if($check !== false) {
                $uploadOk = 1;
            } else {
                echo "<p class='error'>File is not an image.</p>";
                echo "<button class='button' onclick=\"location.href='teachers_homepage.php'\">Proceed to Homepage</button>";            
                $uploadOk = 0;
            }

            // Check file size
            if ($_FILES["profile_pic"]["size"] > 500000) {
                echo "<p class='error'>Sorry, your file is too large.</p>";
                echo "<button class='button' onclick=\"location.href='teachers_homepage.php'\">Proceed to Homepage</button>";            
                $uploadOk = 0;
            }

            // Allow only certain file formats
            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
            && $imageFileType != "gif" ) {
                echo "<p class='error'>Sorry, only JPG, JPEG, PNG & GIF files are allowed.</p>";
                echo "<button class='button' onclick=\"location.href='teachers_homepage.php'\">Proceed to Homepage</button>";            
                $uploadOk = 0;
            }

            // If everything is ok, try to upload file
            if ($uploadOk == 0) {
                echo "<p class='error'>Sorry, your file was not uploaded.</p>";
            } else {
                if (move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $target_file)) {
                    echo "<p class='success'>The file ". htmlspecialchars( basename( $_FILES["profile_pic"]["name"])). " has been uploaded.</p>";
                    $profile_pic = $target_file;

                    // Update teacher's profile in the database
                    $teacher_id = $_SESSION['teacher_id'];
                    $sql = "UPDATE teachers SET NAME='$name', Bio='$bio', teachers_pic='$profile_pic' WHERE teacher_id='$teacher_id'";
                    
                    if ($conn->query($sql) === TRUE) {
                        echo "<p class='success'> Profile updated successfully</p>";
                        echo "<button class='button' onclick=\"location.href='teachers_homepage.php'\">Proceed to Homepage</button>";            
                    } else {
                        echo "<p class='error'>Error updating profile: </p>" . $conn->error;
                        echo "<button class='button' onclick=\"location.href='teachers_homepage.php'\">Proceed to Homepage</button>";            

                    }
                } else {
                    echo "<p class='error'>Sorry, there was an error uploading your file.</p>";
                    echo "<button class='button' onclick=\"location.href='teachers_homepage.php'\">Proceed to Homepage</button>";            
                }
            }
        }
    echo '</div>';
    // Close connection
    $conn->close();
    ?>
</body>
</html>