<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "eduhub_database";
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $email = $_POST['loginEmail'];
    $password = $_POST['loginPassword'];

    $sql = "SELECT * FROM admins WHERE email = '$email' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $_SESSION['admin'] = true;
        header("Location: admin_dashboard.php"); 
    } else {
        echo "Invalid email or password. Please try again.";
    }

    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Admin Login</title>
  <style>
    body {
      font-family: 'Arial', sans-serif;
      background-color: #343a40; /* Dark background color */
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
      margin: 0;
    }

    .container {
      display: flex;
      flex-direction: column;
      width: 500px;
      height: 500px;
      background-color: #495057; /* Darker background color */
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.5); /* Darker shadow */
      overflow: hidden;
    }

    input {
      width: 100%;
      padding: 12px;
      margin: 18px 0;
      box-sizing: border-box;
      background-color: white; /* Dark input background color */
      color: black; /* Light text color */
      border: 1px solid black; /* Slightly lighter border color */
      border-radius: 5px;
    }

    input:hover{
      box-shadow: 0 0 5px black;
    }

    form {
      padding: 20px;
    }

    .head {
      text-align: center;
      color: white;
      font-size: 24px;
      margin-bottom: 20px;
      margin-top: 30px;
    }

    a {
      color: black;
      text-decoration: none;
      margin-bottom: 10px;
      display: inline-block;
    }

    .button {
      background-color: white;
      color: black;
      border: 1px solid black;
      border-radius: 5px;
      padding: 12px;
      cursor: pointer;
      width: 100%;
      transition: transform .6s;
    }

    .button:hover{
      box-shadow: 0 0 5px black;
      transform: scale(1.05);
      background-color: rgb(210,210,210);
    }

    .signup {
      text-align: center;
    }

    .signup label {
      color: black;
      cursor: pointer;
      margin-left: 5px;
    }

    .registration-form {
      display: none;
    }

  </style>
</head>
<body>
  <div class="container">
    <div class="login-form">
      <br></br>
      <h1 class="head">Admin Login</h1>
      <form action="admin_login.php" method="post">
        <input type="text" name="loginEmail" placeholder="Enter your email">
        <input type="password" name="loginPassword" placeholder="Enter your password">
        <a href="#">Forgot password?</a>
        <input type="submit" class="button" value="Login">
      </form>
    </div>

    
</body>
</html>
