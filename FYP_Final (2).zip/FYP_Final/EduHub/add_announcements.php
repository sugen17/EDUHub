<?php
if(isset($_GET['class_id'])) {
    $class_id = $_GET['class_id'];

} else {
    echo "Class ID Not Provided";
    exit; 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="add_anouncements.css">
    <title>Add Announcement</title>
</head>
<body>
<header>
        <h1>EduHub</h1>
    </header>
    <main>
        <div class="top">
            <button onclick="history.back()">Cancel</button>
        </div>

        <div class="main">
            <h1>Add Announcement</h1>
            <form action="add_announcements_process.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="class_id" value="<?php echo $class_id; ?>">
                <label for="topic">Topic:</label>
                <input type="text" id="topic" name="topic"><br>
                <label for="caption">Caption:</label>
                <textarea id="caption" name="caption"></textarea><br>
                <label for="files">Upload Files:</label>
                <input type="file" id="files" name="files[]" multiple><br>
                <label for="due_date">Due Date:</label>
                <input type="date" id="due_date" name="due_date"><br>
                <label for="due_time">Due Time:</label>
                <input type="time" id="due_time" name="due_time"><br>
                <input type="submit" value="Submit">
            </form>
        </div>
</body>
</html>
