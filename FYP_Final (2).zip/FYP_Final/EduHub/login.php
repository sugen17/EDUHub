<!DOCTYPE html>
<html>
<head>
    <title>Delete Class</title>
    <link rel="stylesheet" type="text/css" href="Teacher_drop.css">
</head>
<body>
    <?php
    session_start();

    // Connect to the database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "eduhub_database";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $loginEmail = $_POST['loginEmail'];
        $loginPassword = $_POST['loginPassword'];

        // Validate user credentials
        $query = "SELECT * FROM users WHERE email='$loginEmail'";
        $result = $conn->query($query);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            // Inside the if statement where login is successful
            echo '<div class="notif">';
                if (password_verify($loginPassword, $row['password'])) {
                    // Store user's name in a session variable
                    $_SESSION['username'] = $row['email']; // Assuming the name column in your database is 'name'
                    $_SESSION['student'] = $row['user_id'];
                    // Redirect to classroom.html
                    header("Location: homepage.php");
                
                    exit();
                }
                else {
                            echo '<p class="error">Incorrect password!</p>';
                            echo '<button class="button" onclick="history.back()">Go Back to Login</button>';
                        }
                    } else {
                        echo "<p class='error'>User not found!</p>";
                        echo "<button class='button' onclick='history.back()'>Go Back to Login</button>";
                    }
            echo '</div>';
    }

    // Close the database connection
    $conn->close();
    ?>
</body>
</html>