<?php
session_start();

// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eduhub_database";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_POST['user_id'];
    $email = $_POST['email'];
    $new_password = $_POST['new_password'];

    // Check if the user_id and email combination exist in the database
    $sql = "SELECT * FROM users WHERE user_id = '$user_id' AND email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Update the password in the database
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $update_sql = "UPDATE users SET password = '$hashed_password' WHERE user_id = '$user_id'";
        if ($conn->query($update_sql) === TRUE) {
            echo "Password updated successfully.";
        } else {
            echo "Error updating password: " . $conn->error;
        }
    } else {
        echo "Invalid user_id or email.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Forget Password</title>
    <!-- Bootstrap CSS -->
    <link href="login.css" rel="stylesheet">
    <style>
        body {
      font-family: 'Arial', sans-serif;
      background-color: #343a40; /* Dark background color */
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
      margin: 0;
    }

    .container {
      display: flex;
      flex-direction: column;
      width: 500px;
      height: 500px;
      background-color: #495057; /* Darker background color */
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.5); /* Darker shadow */
      overflow: hidden;
    }

    input {
      width: 100%;
      padding: 12px;
      margin: 18px 0;
      box-sizing: border-box;
      background-color: white; /* Dark input background color */
      color: black; /* Light text color */
      border: 1px solid black; /* Slightly lighter border color */
      border-radius: 5px;
    }

    input:hover{
      box-shadow: 0 0 5px black;
    }

    form {
      padding: 20px;
    }

    .head {
      text-align: center;
      color: white;
      font-size: 24px;
      margin-bottom: 20px;
      margin-top: 30px;
    }

    a {
      color: black;
      text-decoration: none;
      margin-bottom: 10px;
      display: inline-block;
    }

    .button {
      background-color: white;
      color: black;
      border: 1px solid black;
      border-radius: 5px;
      padding: 12px;
      cursor: pointer;
      width: 100%;
      transition: transform .6s;
    }

    .button:hover{
      box-shadow: 0 0 5px black;
      transform: scale(1.05);
      background-color: rgb(210,210,210);
    }
    </style>
</head>
<body>
    <div class="container">              
        <div class="login-form">
            <h1 class="head">Forget Password</h1>      
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">             
                <input type="text" class="form-control" id="user_id" name="user_id" placeholder="Enter your User ID" required>                   
                <input type="email" class="form-control" id="email" name="email" placeholder="Enter your Email" required>                   
                <input type="password" class="form-control" id="new_password" name="new_password" placeholder="Enter your New Password (Minimum 8 characters)" required minlength="8">                  
                <input type="submit" class="button" value="Submit">
            </form>
        </div>    
    </div>
</body>
</html>
