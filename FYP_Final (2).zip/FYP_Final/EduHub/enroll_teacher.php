<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eduhub_database";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $teacher_id = $_POST['teacher_id'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO teachers (teacher_id, email, password) VALUES ('$teacher_id', '$email', '$hashed_password')";

    if ($conn->query($sql) === TRUE) {
        echo '<script>alert("Teacher Sign up successfully");</script>';
        echo '<script>window.location.href = "admin_dashboard.php";</script>';
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="admin.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enroll Student</title>
    <script>
        function openAdminProfile() {
            window.location.href = 'admin_profile.php';
        }

        function goToEnrollStudent() {
            window.location.href = 'enroll_student.php';
        }

        function goToDropStudent() {
            window.location.href = 'drop_student.php';
        }

        function goToEnrollTeacher() {
            window.location.href = 'enroll_teacher.php';
        }

        function goToDropTeacher() {
            window.location.href = 'drop_teacher.php';
        }
    </script>
    <style>
        label {
            display: block;
            margin-bottom: 8px;
            color: white; 
        }

        h2{
            color:white;
        }
        
        .top {
            background-color: #343a40;
            padding: 15px;
            display: flex;
            justify-content: center;
        }

        input {
            width: 100%;
            padding: 12px;
            margin-bottom: 16px;
            box-sizing: border-box;
            background-color: #f9f9f9; 
            color: #333; 
            border: 1px solid #ddd; 
            border-radius: 5px;
        }

        input[type="submit"] {
            background-color: #007bff; 
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 12px;
            cursor: pointer;
            width: 100%;
        }

        input[type="submit"]:hover {
            background-color: #0056b3; 
        }

        button{
            border-style: none;
            border: none;
            background-color: #343a40;
            color: white;
            font-size: 20px;
            transition: transform .6s;
            cursor: pointer;
        }

        button:hover{
            transform: scale(1.3);
        }
    </style>
</head>
<body>
    <header>
        <h1>EduHub</h1>
    </header>
    <main>
        <div class="top">
            <button type="submit" onClick="history.back()">Back to Dashboard</button>
        </div>
    <div class="main">
        <div class="enroll-form">
            <h2>Enroll Teacher</h2>
            <form action="" method="post">
                <label for="student_id">Teacher ID:</label>
                <input type="text" name="teacher_id" required>

                <label for="email">Email:</label>
                <input type="email" name="email" required>

                <label for="password">Password:</label>
                <input type="password" name="password" required>

                <input type="submit" value="Enroll Teacher">
            </form>
        </div>
    </main>
</body>
</html>
