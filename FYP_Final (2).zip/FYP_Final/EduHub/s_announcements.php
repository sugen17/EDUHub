<?php
// Check if class ID is provided
if(isset($_GET['class_id'])) {
    $class_id = $_GET['class_id'];

    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "eduhub_database";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT topic, caption, document_names, due_date, due_time FROM announcements WHERE class_id = $class_id";
    $result = $conn->query($sql);

    $conn->close();
} else {
    echo "Class ID Not Provided";
    

    exit; // Stop execution if class ID is not provided
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="s_announcement.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Announcements</title>
    
</head>
<body>
    <header>
        <h1>EduHub</h1>
    </header>
    <div class="top">
        <a href="homepage.php">
        <p class="choose">Back to Homepage </p>
    </a> 
        <div class="dropdown" style="float:right;">
                <img src="FYP Images/dropdown.png" class="dropbtn">
                <div class="dropdown-content">
                    <a href="classroom.php?class_id=<?php echo $class_id; ?>">Classroom</a>
                  <a href="#">Announcements</a>
                  <a href="classwork.php?class_id=<?php echo $class_id; ?>">Classwork</a>
                  <a href="students.php?class_id=<?php echo $class_id; ?>">Students</a>
                </div>
            </div>
        <a href="student_profile.php">
        <img class="profile" src="FYP Images/Profile pic.jpg">
    </a>
    </div>

    <div class="main">
        <h1 class="announce">Announcements</h1>

        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<div class='announcement'>";
                echo "<h2>" . $row['topic'] . "</h2>";
                echo "<p><strong>Caption:</strong> " . $row['caption'] . "</p>";
                echo "<p><strong>Document Names:</strong> " . $row['document_names'] . "</p>";
                echo "<p><strong>Due Date:</strong> " . $row['due_date'] . "</p>";
                echo "<p><strong>Due Time:</strong> " . $row['due_time'] . "</p>";
                echo "</div>";
            }
        } else {
            echo "No announcements found for this class.";
        }
        ?>

    </div>
    
</body>
</html>
