<!DOCTYPE html>
<html>
<head>
    <title>Delete Class</title>
    <link rel="stylesheet" type="text/css" href="Teacher_drop.css">
</head>
<body>
    <?php
    // Connect to the database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "eduhub_database";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    echo '<div class="notif">';
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $signupEmail = $_POST['signupEmail'];
            $signupPassword = $_POST['signupPassword'];
            $confirmPassword = $_POST['confirmPassword'];

            // Validate and insert user information into the database
            if ($signupPassword === $confirmPassword) {
                // Generate a unique custom user ID
                $customUserId = generateUniqueUserId($conn);

                // Hash the password
                $hashedPassword = password_hash($signupPassword, PASSWORD_DEFAULT);

                // Insert data into the users table
                $insertQuery = "INSERT INTO users (user_id, email, password) VALUES ('$customUserId', '$signupEmail', '$hashedPassword')";

                if ($conn->query($insertQuery) === TRUE) {
                    echo "<p class='success'>Signup successful!</p>";
                    echo "<button class='button' onclick=\"location.href='homepage.php'\">Proceed to Homepage</button>";            

                    $subject = "Welcome to EduHub";
                    $message = "Thank you for signing up! Your user ID is: $customUserId";
                    $headers = "From: businesseduhub@gmail.com"; // Replace with your Gmail address
                    
                    // Uncomment the line below when you're ready to test on a live server
                    // mail($signupEmail, $subject, $message, $headers);
                    
                } else {
                    echo "Error: " . $insertQuery . "<br>" . $conn->error;
                }
            } else {
                echo "<p class='error'>Passwords do not match!</p>";
                echo "<button class='button' onclick=\"location.href='student login.html'\">Proceed to Homepage</button>";            
            }
        }
    echo '</div>';

    // Close the database connection
    $conn->close();

    // Function to generate a unique user ID
    function generateUniqueUserId($conn) {
        $nextId = 0;

        do {
            // Generate a numeric part of the user ID
            $query = "SELECT MAX(CAST(SUBSTRING(user_id, 7) AS SIGNED)) + 1 AS next_id FROM users";
            $result = $conn->query($query);

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $nextId = $row['next_id'];
            } else {
                // If there are no existing users, start from 1
                $nextId = 1;
            }

            // Generate the complete user ID (with 6 digits)
            $customUserId = "1111" . str_pad($nextId, 4, '0', STR_PAD_LEFT);

            // Check if the generated user ID already exists
            $checkQuery = "SELECT user_id FROM users WHERE user_id = '$customUserId'";
            $checkResult = $conn->query($checkQuery);

        } while ($checkResult->num_rows > 0);

        return $customUserId;
    }
    ?>
</body>
</html>