<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="teacher_profile.css">
    <title>Teacher Profile</title>
</head>
<body>
    <header>
        <h1>EduHub</h1>
    </header>
    <div class="top">
        <button class="back" onclick="history.back()">Go back</button>
    </div>
    <div class="main">
        <?php
        session_start();

        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "eduhub_database";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $teacher_id = $_SESSION['teacher_id'];
        $sql = "SELECT * FROM teachers WHERE teacher_id = '$teacher_id'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $teacher_name = $row['NAME'];
            $teacher_id = $row['teacher_id'];
            $teacher_email = $row['email'];
            $teacher_bio = $row['Bio'];
            $teacher_pic = $row['teachers_pic'];

            echo '
                <h1> Personal Info </h1>
                <img src="' . $teacher_pic . '" alt="Profile Picture">
                <br>
                <h2>Full Name : ' . $teacher_name . '</h2>
                <br></br>
                <h2>ID : ' . $teacher_id . '</h2>
                <br></br>
                <h2>Email : ' . $teacher_email . '</h2>
                <br></br>
                <h2>Bio : ' . $teacher_bio . '</h2>
                <br></br>
                <form action="update_teachers_profile.php" method="post">
                    <button type="submit" class="but">Update Profile</button>
                </form>';

            echo '<form action="logout.php" method="post">
                    <button type="submit" class="but">Logout</button>
                </form>';
        } else {
            echo "Teacher not found.";
        }

        $conn->close();
        ?>
    </div>
</body>
</html>
