-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 26, 2024 at 01:05 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eduhub_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `email`, `password`) VALUES
(1, 'admin@gmail.com', 'adminpw');

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `class_id` int(11) NOT NULL,
  `topic` varchar(255) NOT NULL,
  `caption` text NOT NULL,
  `document_names` text DEFAULT NULL,
  `due_date` date NOT NULL,
  `due_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`class_id`, `topic`, `caption`, `document_names`, `due_date`, `due_time`) VALUES
(55, 'Past Year Question', 'Pls finish it', 'FINAL EXAM 2220 MT2 A.pdf', '2024-02-13', '14:06:00'),
(55, 'sefs', 'awf', 'IMG_4119.MOV', '2024-02-23', '19:14:00');

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `id` int(11) NOT NULL,
  `xteacher_id` int(11) NOT NULL,
  `class_name` varchar(255) NOT NULL,
  `class_code` varchar(20) NOT NULL,
  `class_image` varchar(255) NOT NULL,
  `due_date` date NOT NULL DEFAULT curdate(),
  `asdf` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`id`, `xteacher_id`, `class_name`, `class_code`, `class_image`, `due_date`, `asdf`) VALUES
(55, 22220004, 'Biology', '190', 'b42ae123-92b1-4e40-b988-2f711c5bd197.png', '2024-02-19', ''),
(56, 22220004, 'English', '684', 'english-language-irregularities.jpeg', '2024-02-19', '');

-- --------------------------------------------------------

--
-- Table structure for table `enrollment_table`
--

CREATE TABLE `enrollment_table` (
  `enrollment_id` int(11) NOT NULL,
  `enrollment_date` date DEFAULT NULL,
  `id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `xclass_code` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `enrollment_table`
--

INSERT INTO `enrollment_table` (`enrollment_id`, `enrollment_date`, `id`, `user_id`, `xclass_code`) VALUES
(15, '2024-02-19', 56, 11110000, 684),
(17, '2024-02-19', 56, 11110009, 684),
(18, '2024-02-24', 56, 11110013, 684),
(19, '2024-02-26', 56, 11110014, 684);

-- --------------------------------------------------------

--
-- Table structure for table `submissions`
--

CREATE TABLE `submissions` (
  `submission_id` int(11) NOT NULL,
  `class_id` int(11) DEFAULT NULL,
  `class_name` varchar(255) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `topic` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `submissions`
--

INSERT INTO `submissions` (`submission_id`, `class_id`, `class_name`, `student_id`, `file_path`, `topic`) VALUES
(1, 33, 'Maths', 11110002, 'uploads/Maths/895528.jpg', 'Graph'),
(3, 34, 'Biology', 11110003, 'uploads/Biology/micro.jpg', 'Microorganisms'),
(4, 54, 'maths', 11110000, 'uploads/maths/FINAL EXAM 2220 MT2 A.pdf', 'Past Year Question');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `teacher_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `NAME` varchar(100) NOT NULL,
  `Bio` varchar(255) NOT NULL,
  `teachers_pic` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`teacher_id`, `email`, `password`, `NAME`, `Bio`, `teachers_pic`) VALUES
(22220002, 'TA@gmail.com', '$2y$10$LjinjtmcyLqsM.zkV7ODzekE.kSwRsHgVobEn.BdU4oF/jlWizuf2', '', '', ''),
(22220003, 'test@gmail.com', '$2y$10$7x8Dry7UGk9nNUKOtKsnVOLKX/nFkK4p8Xg3.S58mICC6J5KuSWYK', 'Omar Adam', 'testing lecturer', 'profile_pictures/boyle.png'),
(22220004, 'sugensanthiran@gmail.com', '$2y$10$eFyaRz3g3l7h6s4IGCNkvuJEIjr86Dn/z6uNTbXLu.U1CDyMCzxNW', 'SIM JUN LING', 'CAR', 'profile_pictures/photo_1_2023-09-13_10-25-01.jpg'),
(22220005, 'yum@mmu.edu.my', '$2y$10$5c9QtpRS62QOVBt0HgJffOn6P.stWi8YWjCOnhRXW/rFRbTkZJFau', '', '', ''),
(22220006, 'justin@fireworks.digital', '$2y$10$tt4cBlW1UEokEkH1xZtYnuX2KqdOC/.zW5BOgAnDwwFyEVk1eJM/W', '', '', ''),
(22220007, 'STUDYWITHME1708@GMAIL.COM', '$2y$10$5nYWyNDPkRWMOCeZW1BDuezfSZ8FIxgNZuls.t/5guGZ6hrZiPvnK', '', '', ''),
(22220009, 'shengchi6129@gmail.com', '$2y$10$g/IQvYwt3XkEmiaswmQYZOYj6ZJ1zDJ1BRCJqZfIUwcO8PBtgcS7.', '', '', ''),
(22220010, 'admin@gmail.com', '$2y$10$87XftJ5G2TsnP0.iUpWCL.a942Ozf1MfoB/M35gBw1jMzVBzq38g2', '', '', ''),
(22220011, 'rajathi14@gmail.com', '$2y$10$XgX8sMtlu6CrAgT.2CGSjOhzxuim0U3cIbvgbbfiTO82noB/4KKqq', '', '', ''),
(22220012, 'drgdg@drgd.coom', '$2y$10$Q0W8E4eW.sp9oqqvTauD8.hxjZ5IQ0FP2uct3lw6gMGmvj4u7jXja', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_id` varchar(10) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `pic` varchar(255) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `bio` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_id`, `email`, `password`, `pic`, `fullname`, `bio`) VALUES
(72, '11110000', 'sugensanthiran@gmail.com', '$2y$10$T4oYkvFN4ZFgT1bEbkzn6OtvRdoQbYzFXtl7Wg6tQ.TsX86opVcn.', 'IMG_0064.JPG', 'sugen', 'cdar'),
(73, '11110001', '1211205436@student.mmu.edu.my', '$2y$10$IjnaxnyRtAAEDC0s6FkKrOUnTHxGvJQZduXd0W7fU1cfhm3BQxevu', '', '', ''),
(74, '11110002', 'abc', '$2y$10$WdKa1gHt0aFNr.Rr7xdodOdJ92.pyXMqeHvU4tkOE7q5KN9eEwkhq', '', '', ''),
(75, '11110009', 'sugenbilla@yahoo.com', '$2y$10$uVUW6MxGy7GpZfjZApd6bu0t7ROj.9lO4HpTcyzSCmnJqyU9doRIy', '', '', ''),
(76, '11110010', 'drgdg@drgd.coom', '$2y$10$DaY.kZ0p/.T6BRlMKiRWQupc/crKGq8t.nIJws4WMD5iRZtKBANLe', '', '', ''),
(77, '11110011', 'justin@fireworks.digital', '$2y$10$LqFdB.FWJO3tDFm24Pwud.9Ho06rDHvm7lmYTIFH/eGBir9JHcv0u', '', '', ''),
(78, '11110012', 'shengchi6129@gmail.com', '$2y$10$8ELihSl4aSNjJ2UOUd2AyeiLfSyprTqrT9Ytw9xV0pnkeKFFvBCgG', '', '', ''),
(79, '11110013', 'rajathi14@gmail.com', '$2y$10$FwUlK6RtnMrBFvmN23qrmegdR.5EU4NEIPWuB7c7XhNw485dgDNNe', 'photo_1_2023-09-19_14-55-35.jpg', '', ''),
(80, '11110014', 'studywithme1708@gmail.com', '$2y$10$KCkQKY5Wdtx1md8OIs740eMocr0wBMcoQ88vIUKN7MZWhNZ8mDv0q', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_profiles`
--

CREATE TABLE `user_profiles` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `bio` text NOT NULL,
  `profile_picture` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_profiles`
--

INSERT INTO `user_profiles` (`id`, `fullname`, `bio`, `profile_picture`) VALUES
(1, 'Sugenthiraan A/L Santhiran', 'aefa', 'profile_pictures/photo_2023-12-26_18-58-33.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD KEY `an_id` (`class_id`);

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `xteacher_id_fk` (`xteacher_id`);

--
-- Indexes for table `enrollment_table`
--
ALTER TABLE `enrollment_table`
  ADD PRIMARY KEY (`enrollment_id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `submissions`
--
ALTER TABLE `submissions`
  ADD PRIMARY KEY (`submission_id`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`teacher_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `enrollment_table`
--
ALTER TABLE `enrollment_table`
  MODIFY `enrollment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `submissions`
--
ALTER TABLE `submissions`
  MODIFY `submission_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `teacher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22220013;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `user_profiles`
--
ALTER TABLE `user_profiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `announcements`
--
ALTER TABLE `announcements`
  ADD CONSTRAINT `announcements_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `classes`
--
ALTER TABLE `classes`
  ADD CONSTRAINT `classes_ibfk_1` FOREIGN KEY (`xteacher_id`) REFERENCES `teachers` (`teacher_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `enrollment_table`
--
ALTER TABLE `enrollment_table`
  ADD CONSTRAINT `enrollment_table_ibfk_1` FOREIGN KEY (`id`) REFERENCES `classes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
